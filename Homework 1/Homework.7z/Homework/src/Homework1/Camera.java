package Homework1;

class Camera extends ModelElement {
    int resolution;

    public Camera(String name, int resolution) {
        super(name);
        this.resolution = resolution;
    }
}

package Homework1;

class Texture extends ModelElement {
    String image;

    public Texture(String name, String image) {
        super(name);
        this.image = image;
    }
}

package Homework1;

class Flash extends ModelElement {
    public Flash(String name) {
        super(name);
    }
}
package Homework1;

class ModelElement {
    String name;

    public ModelElement(String name) {
        this.name = name;
    }
}

package Homework1;

class Vertex {
}
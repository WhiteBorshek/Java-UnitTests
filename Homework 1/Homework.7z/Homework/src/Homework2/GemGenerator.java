package Homework2;

public class GemGenerator extends ItemFabric {
    @Override
    public iGameItem createItem() {
        System.out.println("Создал новый сундук с драгоценностями");
        return new GemReward();
    }
}


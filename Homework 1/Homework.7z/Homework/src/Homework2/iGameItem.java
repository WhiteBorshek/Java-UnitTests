package Homework2;

public interface iGameItem {
    void open();
}


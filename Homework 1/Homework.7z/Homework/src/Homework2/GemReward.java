package Homework2;

public class GemReward implements iGameItem {
    @Override
    public void open() {
        System.out.println("Gem");
    }
}


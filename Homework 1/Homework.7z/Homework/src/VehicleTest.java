import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class VehicleTest {

    @Test
    void carIsInstanceOfVehicle() {
        Vehicle car = new Car();
        assertTrue(car instanceof Vehicle);
    }

    @Test
    void carHasFourWheels() {
        Vehicle car = new Car();
        assertEquals(4, car.getNumWheels());
    }

    @Test
    void motorcycleHasTwoWheels() {
        Vehicle motorcycle = new Motorcycle();
        assertEquals(2, motorcycle.getNumWheels());
    }

    @Test
    void carTestDriveSetsSpeedTo60() {
        Vehicle car = new Car();
        car.testDrive();
        assertEquals(60, car.getSpeed());
    }

    @Test
    void motorcycleTestDriveSetsSpeedTo75() {
        Vehicle motorcycle = new Motorcycle();
        motorcycle.testDrive();
        assertEquals(75, motorcycle.getSpeed());
    }

    @Test
    void carParkSetsSpeedToZero() {
        Vehicle car = new Car();
        car.testDrive();
        car.park();
        assertEquals(0, car.getSpeed());
    }

    @Test
    void motorcycleParkSetsSpeedToZero() {
        Vehicle motorcycle = new Motorcycle();
        motorcycle.testDrive();
        motorcycle.park();
        assertEquals(0, motorcycle.getSpeed());
    }
}
